<?php
include __DIR__."/cms/config.php";
if (!isset($_FILES['careers_app_file']['tmp_name'])) {
	}else{

		$file=$_FILES['careers_app_file']['tmp_name'];
		$image= addslashes(file_get_contents($_FILES['careers_app_file']['tmp_name']));
		$image_name= addslashes($_FILES['careers_app_file']['name']);
			
			move_uploaded_file($_FILES["careers_app_file"]["tmp_name"],"career-application/" . $_FILES["careers_app_file"]["name"]);
			
			
			$career_app_file=$_FILES["careers_app_file"]["name"];
			$careers_app_fname=$_POST['careers_app_fname'];
			$careers_app_lname=$_POST['careers_app_lname'];
			$careers_app_email=$_POST['careers_app_email'];
			$careers_app_number=$_POST['careers_app_number'];
			$careers_app_gender=$_POST['careers_app_gender'];
			$careers_app_position=$_POST['careers_app_position'];
			$subject="You Have New Application";
			$to = "socialconz@gmail.com, guiller.socialconz@gmail.com";
			$msg = "You Have New Applicants";
			$header="Hi Ms.Rona🖐";


			mail($to,$subject,$msg,$header);

			
			$sql=mysqli_query($con,"INSERT INTO table_careers_application (careers_app_file ,careers_app_fname, careers_app_lname, careers_app_email, careers_app_number, careers_app_gender, careers_app_position , date_apply) VALUES ('$career_app_file','$careers_app_fname','$careers_app_lname','$careers_app_email','$careers_app_number','$careers_app_gender','$careers_app_position',now())");

		
			header('location: careers-application.php?sending_success');
			exit();					
	}
?>
