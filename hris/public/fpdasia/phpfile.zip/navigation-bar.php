  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Proxima+Nova">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/b52241fb5f.js"></script>
        <link rel="stylesheet" type="text/css" href="fpdasia-css/index.css">
              <!-- 1. Add latest jQuery and fancybox files -->

<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
<style type="text/css">
.nav-link{
    padding: .5rem;
  }
    .dropdown:hover .dropdown-menu{
    display: block;
  }.hov2:hover .dropdown-item { color: red; }
.hov2:focus .dropdown-item { color: red; }
   @media only screen and (max-width: 991px){
.gif{
  width: 20%;
}
.gif2{
  width: 60%;
}
}

  .mrl{
    margin-left: 150px;
    margin-right: 150px;
  }
  @media only screen and (max-width: 991px){
     .mrl{
    margin-left: 50px;
    margin-right: 50px;
  }
  }
   @media only screen and (max-width: 768px){
     .mrl{
    margin-left: 9px;
    margin-right: 9px;
  }
  }
</style>

  <nav class="navbar fixed-top navbar-expand-lg bg-white text-uppercase">
        
        <a class="navbar-brand" href="index.php">
          <img src="Gallery of Website/Logo/Company Logo.png" width="90px" class="logo-css">
        </a>

         <button style="outline: none;" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
           <span class="fas fa-bars nav-icon pr-3" ></span>
         </button>

     <div class=" collapse navbar-collapse" id="navbarNav" style="position: right">
      <div class="row ml-auto">
      <ul class=" nav font-size col-lg-3 ml-auto" style="font-size: 15px;">
        <li class="nav-item nav-item-resp ">
          <div class="hov">
          <a class=" hover-text-gray nav-link" href="contactus.php">Contact</a>
          </div>
        </li>
        <li class="nav-item nav-item-resp nav-none">
          <div>
          <a class=" nav-link"><span class="text-dark"> | </span></a>
        </div>
        </li>
        <li class="nav-item nav-item-resp ">
          <div class="hov">
          <a href="cms/login.php" class="hover-text-gray nav-link">Login</a>
        </div>
        </li>
      </ul>
       <ul class=" nav font-size col-lg-12">
        <li class="nav-item  nav-item-resp ml-auto">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="index.php">Home</a>
          </div>
        </li>
        <li class="nav-item nav-item-resp dropdown">
          <div class="hov">
          <a class="nav-link  hover-text-color " href="about.php" id="navbarDropdown" role="button" aria-haspopup="true" aria-expanded="false">About</a>

          <div class=" dropdown-menu" aria-labelledby="nav-item">
            <div class="hov2">
              <a class="dropdown-item" href="about.php#history">History</a>
            </div>
            <div class="hov2">
              <a class="dropdown-item" href="about.php#vissionmission">Vision & Mission</a>
            </div>
            <div class="hov2">
              <a class="dropdown-item" href="about.php#qualitypolicy">Quality Policy</a>
            </div>
            <div class="hov2">
              <a class="dropdown-item" href="about.php#corpvalues">Corporate Values</a>
            </div>
            <div class="hov2">
              <a class="dropdown-item" href="about.php#certification">Certification</a>
            </div>
            <div class="hov2">
              <a class="dropdown-item" href="about.php#partners">Our Partners</a>
            </div>
          </div>
          </div>
          
        </li>
        <!-- <li class="nav-item nav-item-resp ">
          <div class="hov">
            <a class=" hover-text-color nav-link" href="property-management.php">Property Management</a>
          </div>
        </li> -->
        <li class="nav-item nav-item-resp ">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="services.php">Services</a>
          </div>
        </li>
        <li class="nav-item nav-item-resp ">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="gallery.php?albums">Gallery</a>
          </div>
        </li>
          <li class="nav-item nav-item-resp ">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="news-and-updates-view.php">News & Updates</a>
          </div>
        </li>

        <li class="nav-item nav-item-resp">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="careers-application.php">Careers</a>
          </div>
        </li>
        <li class="nav-item nav-item-resp">
          <div class="hov">
          <a class=" hover-text-color nav-link" href="coolfix.php">CoolFix</a>
          </div>
        </li>
        <li class="mx-3">
        </li>
        
        
       </ul>
       </div>
      </div>
    </nav><br><br><br>
    <script>
  AOS.init();
</script>

    <script type="text/javascript">
         var screen_width = window.outerWidth;
  var screen_height = window.outerHeight;

  var scroll_top = window.onscroll = function() {
    scroll_top = window.pageYOffset;
  };

$(window).on('scroll load', function () {
    animateNavbar();

   
  });

  function animateNavbar() {
  if (screen_width >= 991 ) {
    if (scroll_top > 0) {
      $('.navbar').addClass('bg-white active');
      $('.navbar-brand ').css({
        'height': '75px',
        'transition': '.5s'
      });
      $('.logo-css').css({
        'width': '60px',
        'transition': '.6s'
      });
    }
    else {
      $('.navbar').addClass('bg-white active');
      $('.navbar-brand ').css({
        'height': '115px',
        'transition': '.5s'
      });
      $('.logo-css').css({
        'width': '98px',
        'transition': '.6s'
      });
    }
  }
}
    </script>
</html>
