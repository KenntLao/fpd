<style type="text/css">
  /*  .text-l{*/
  /*  text-align:left;*/
  /*}*/
  /*@media only screen and (max-width: 991px){*/
  /*  .text-l{*/
  /*  text-align:center;*/
  /*}*/
  /*}*/
  /*.none{*/
  /*  display: inline;*/
  /*}*/
  /*@media only screen and (max-width: 1200px){*/
  /*  .none{*/
  /*  display: none;*/
  /*}*/
  /*}*/
</style>
<!--Contact Us Section-->

  <!--<div class="container-contact bg-white" style="margin: 0;">-->
  <!--  <div class="container">-->
  <!--  <div class="form-row  pt-3">-->

  <!--    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-12 text-l">-->
  <!--      <img src="Gallery of Website/Logo/Company Logo.png" width="100px" class="bg-white m-0">-->
    
  <!--    </div><div class="col-lg-2 col-md-3 col-sm-6 col-xs-12 text-l" -->
  <!--    style="font-size:14px;">-->
  <!--      <p class="mt-3">-->
  <!--        <a class="text-dark" href="property-management.php">Properties</a><br>-->
  <!--        <a class="text-dark" href="">Project Management</a><br>-->
  <!--        <a class="text-dark" href="property-management-view.php?pm_id=3">Facilities Management</a>-->
  <!--      </p>-->
    
  <!--    </div>-->

  <!--    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-12 text-l" style="font-size:15px;">-->
  <!--     <p class="mt-3">-->
  <!--        <a class="text-dark" href="services.php"> Consultancy</a><br>-->
  <!--        <a class="text-dark" href="services-engineer.php#coolfix">Technical Services</a><br>-->
  <!--        <a class="text-dark" href="services-engineer.php">Engineering Services</a>-->
  <!--      </p>-->
          
  <!--    </div>-->

  <!--  <div class="col-lg-2 col-md-3 col-sm-6 col-xs-12 text-l" style="font-size:15px;">-->
  <!--     <p class="mt-3">-->
  <!--        <a class="text-dark" href="about.php">About FPD</a><br>-->
  <!--        <a class="text-dark" href="careers-application.php">Careers</a><br>-->
  <!--        <a class="text-dark" href="news-and-updates-view.php">News & Update</a>-->
  <!--      </p>-->
          
  <!--    </div>-->



  <!--    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 mt-1 text-l ">-->
        
  <!--     <p class=" text-l text-dark" style="font-size: 14px;">-->
  <!--        <i class='fas fa-map-marker-alt text-danger'></i>&nbsp;&nbsp;-->
  <!--        The Penthouse 24H City Hotel -->
  <!--        <span class="none"><br> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</span>P. Ocampo Sr. Extension corner -->
  <!--        <span class="none"><br> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</span>Balagtas Street, Brgy La Paz, Makati City-->
  <!--          <br>-->
            
          
  <!--        <i class='fas fa-mobile-alt text-danger'></i>&nbsp;&nbsp; +63 2 8 815 3737 -->
  <!--         &nbsp;&nbsp;-->

  <!--        <i class='fas fa-fax text-danger text-l'></i>&nbsp;&nbsp;+63 2 8 815 2195-->
  <!--          &nbsp; &nbsp; <br>-->
            
  <!--        <i class="fas fa-envelope text-danger text-l my-auto" ></i>&nbsp;&nbsp;<a href="mailto:inquiry@fpdasia.net" class=" text-dark" style="padding: 0; margin: 0;">inquiry@fpdasia.net</a><br>-->

  <!--      </p>-->
  <!--    </div>-->
 
  <!--  </div>-->
  <!--   </div>-->
  <!--</div>-->

<!--<div class="bg-danger text-white">-->
<!--  <div class="container py-2 small text-center  text-justify">-->
<!--<div class="row">-->
<!--    <div class=" col-lg-6 text-lg-left">-->
<!--    &copy; 2019 FPD Asia Property Services, Inc. All Rights Reserved. &nbsp; &nbsp; -->
<!--    </div>-->
<!--    <div class="col-lg-6 text-lg-right">  -->
<!--    <a class="text-reset" href="terms-and-conditions.php">Terms</a>  and   -->
<!--    <a class="text-reset" href="privacy-and-policy.php">Privacy Policy</a>&nbsp; &nbsp;&nbsp;|&nbsp; &nbsp; -->
<!--    Site Design by <a href="//socialconz.com" class="text-reset" target="_blank">SocialConz Digital</a>&nbsp; &nbsp; &nbsp; &nbsp; -->
<!--    <a href="" class="fab fa-facebook " -->
<!--        style="font-size: 15px; text-decoration: none;"></a>-->

<!--        <a href="https://www.youtube.com/channel/UCmK8b1E6D8DNCaCFgz1Bo_A" target="_blank" -->
<!--        class="fab fa-youtube " style="font-size: 15px; text-decoration: none;"></a>-->

<!--        <a href="https://twitter.com/FPDAsia" target="_blank" class="fab fa-twitter" -->
<!--        style="font-size: 15px; text-decoration: none;"></a>-->

<!--        <a href="https://www.linkedin.com/company/fpd-asia-property-services-inc-/" -->
<!--        target="_blank" class="fab fa-linkedin " -->
<!--        style="font-size: 15px; text-decoration: none;"></a>-->
<!--    </div>-->
<!--</div>-->
<!--  </div>-->
<!--</div>-->

	<style>
	.footer-red{
		background-color: #DB291DFF;
		color: white;
	}
	.footer-dark-red{
		background-color: #cb261a;
		color: white;
	}
	.footer-text{
		font-size: .80em !important;
	}
	.footer-text-2{
		font-size: .70em !important;
	}
	</style>
	<footer>
		<div class="container-fluid py-1 footer-red">
			<ul class="nav d-flex justify-content-lg-between">
              <li class="nav-item">
                <a class="nav-link text-white" href="#">
                	<i class="fas fa-phone-alt fa-fw mr-2"></i> <span class="footer-text">+63 2 8 815 3737 | +63 2 8 815 2195</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-white" href="mailto:inquiry@fpdasia.net"><i class="fas fa-envelope fa-fw mr-2"></i> <span class="footer-text">inquiry@fpdasia.net</span></a>
              </li>
              <li class="nav-item">
               	<a class="nav-link text-white" href="#"><i class="fas fa-map-marker-alt fa-fw mr-2"></i> <span class="footer-text">APW Building 9824 Kamagong St., cor Anubing St., San Antonio, Makati City</span></a>
              </li>
              <li class="nav-item">
                <div class="nav-link text-white">
                	<a class="text-decoration-none text-white fab fa-facebook fa-fw" href="https://www.facebook.com/FPDAsia/"></a>
                	<a class="text-decoration-none text-white fab fa-youtube fa-fw" href=""></a>
                	<a class="text-decoration-none text-white fab fa-twitter fa-fw" href=""></a>
                	<a class="text-decoration-none text-white fab fa-linkedin fa-fw" href=""></a>
                </div>
              </li>
            </ul>
		</div>
		<div class="container-fluid footer-dark-red">
			<ul class="nav d-flex justify-content-between">
				<a class="nav-link" href="#">
					<li class="footer-text-2 text-white">© 2020 FPD Asia Property Services, Inc. All Rights Reserved.</li>
				</a>
				<a class="nav-link" href="#">
					<li class="footer-text-2 text-white">Privacy Policy | Terms & Condition</li>
				</a>
			</ul>
		</div>
	</footer>