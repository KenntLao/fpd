@csrf
<div class="row">
    <div class="col-12 col-md-6">
        <div class="form-group">
            <label class="mr-2" for="name">Document: </label>
            <span class="badge badge-danger">Required</span>
            <input class="form-control required" type="file" name="hrdocs">
        </div>
    </div>
</div>